# Intake questions

Ask only what changes the plan. Max 3, one message. Pick from:

1. What do you sell, and to whom? (industry, B2B or B2C)
2. How many people use Pipedrive, and what roles? (reps, manager, owner, ops, CS)
3. Biggest pain right now? (follow-up, forecast, messy data, lead quality, losing deals, renewals)
4. Typical sales cycle? (days, weeks, months)
5. Which other tools do you use daily? (Slack, Teams, Gmail, Outlook, Google Drive; Pipedrive Nova for calls?)
6. One-off sales or recurring (subscriptions, renewals, reorders)?

Skip any question the case already answers. If the user does not want questions, assume and say so in `Assume:`.
